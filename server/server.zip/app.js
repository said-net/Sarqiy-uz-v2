process.env.NODE_ENV !== 'production' && require('dotenv').config();
const { APP_PORT, MONGO_URI } = require('./src/configs/env');
const express = require('express');
const file = require('express-fileupload');
const cors = require('cors');
const router = require('./src/router');
const shopController = require('./src/controllers/shop.controller');
const shopModel = require('./src/models/shop.model');
const app = express();
require('mongoose').connect(MONGO_URI);
require('./src/controllers/boss.controller').default();
require('./src/controllers/setting.controller').default();
require('./src/configs/folder.config')()
app.use(cors());
app.use(express.json());
app.use(file());
app.use('/public', express.static('public'));
app.post('/target', shopController.getTargetApi);

try {
    app.use('/api', router);
} catch (error) {
    console.log(error);
}
app.listen(APP_PORT, () => {
    try {
        require('./src/bot/app').launch()
    } catch (error) {
        console.log(error);
    }
});

async function AddMoney() {
    let shops = await shopModel.find({ for_admin: 0, status: 'sended' }).populate('product')
    for (let shop of shops) {
        shop.set({for_admin: shop?.product?.for_admins}).save();
    }
}
AddMoney()